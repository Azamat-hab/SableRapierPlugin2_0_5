#!/usr/bin/env python3
"""Заменяет sable_rapier_aarch64_linux.so внутри Sable jar на Android-сборку (bionic).
Использование: patch_sable_jar.py <in.jar> <libsable_rapier.so> <out.jar>"""
import sys, io, zipfile, struct

HEADER = b'\x04\x22\x4d\x18\x60\x70\x73'  # LZ4 frame, 4MB blocks, без чексумм (как в оригинале)
TARGET = 'sable_rapier_aarch64_linux.so'

def lz4_decode(d):
    assert d[:4] == b'\x04\x22\x4d\x18', 'не LZ4 frame'
    flg = d[4]; pos = 6
    if flg & 0x08: pos += 8
    if flg & 0x01: pos += 4
    pos += 1
    blkck = bool(flg & 0x10); out = bytearray()
    while True:
        sz = struct.unpack_from('<I', d, pos)[0]; pos += 4
        if sz == 0: break
        raw = sz & 0x80000000; sz &= 0x7fffffff
        blk = d[pos:pos+sz]; pos += sz
        if blkck: pos += 4
        if raw: out += blk; continue
        i = 0
        while i < len(blk):
            t = blk[i]; i += 1; ll = t >> 4
            if ll == 15:
                while True:
                    b = blk[i]; i += 1; ll += b
                    if b != 255: break
            out += blk[i:i+ll]; i += ll
            if i >= len(blk): break
            off = blk[i] | (blk[i+1] << 8); i += 2; ml = t & 15
            if ml == 15:
                while True:
                    b = blk[i]; i += 1; ml += b
                    if b != 255: break
            ml += 4; s = len(out) - off
            for k in range(ml): out.append(out[s+k])
    return bytes(out)

def lz4_encode(data):  # валидный LZ4 frame из несжатых блоков
    out = bytearray(HEADER); B = 4 * 1024 * 1024
    for i in range(0, len(data), B):
        c = data[i:i+B]; out += struct.pack('<I', len(c) | 0x80000000) + c
    out += struct.pack('<I', 0)
    return bytes(out)

def rewrite(src_bytes, edit):
    zin = zipfile.ZipFile(io.BytesIO(src_bytes)); buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zout:
        for it in zin.infolist():
            data = edit(it.filename, zin.read(it.filename))
            zi = zipfile.ZipInfo(it.filename, it.date_time)
            zi.compress_type = it.compress_type; zi.external_attr = it.external_attr
            zout.writestr(zi, data)
    return buf.getvalue()

def main(src, so, dst):
    android = open(so, 'rb').read()
    assert android[:4] == b'\x7fELF', 'не ELF'
    done = {'n': 0}
    def edit_bundle(name, data):
        if name == TARGET:
            done['n'] += 1; return android
        return data
    def edit_l4z(name, data):
        if name.endswith('sable_rapier_binaries.zip.l4z'):
            return lz4_encode(rewrite(lz4_decode(data), edit_bundle))
        return data
    def edit_inner(name, data):
        if name.startswith('META-INF/jarjar/') and 'sable_rapier' in name and name.endswith('.jar'):
            return rewrite(data, edit_l4z)
        return data
    out = rewrite(open(src, 'rb').read(), edit_inner)
    if not done['n']: sys.exit('ОШИБКА: ' + TARGET + ' не найден в jar')
    open(dst, 'wb').write(out); print('OK ->', dst)

if __name__ == '__main__':
    if len(sys.argv) != 4: sys.exit(__doc__)
    main(*sys.argv[1:])
