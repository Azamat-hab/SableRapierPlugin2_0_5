# Sable 2.0.5 Rapier — Android plugin (сборка через GitHub)

1. Создайте репозиторий, загрузите содержимое этой папки.
2. (Опционально) положите `sable-neoforge-1_21_1-2_0_5.jar` в папку `sable/` — тогда получите ещё и jar с подменённой Android-библиотекой.
3. Actions → *Build Sable Rapier Android plugin* → Run workflow.
4. Скачайте артефакт `sable-rapier-android`: APK плагина, jar и `.so`.

Если сборка падает на поиске Rust-кода — откройте логи шага *Clone/Locate* и задайте `sable_repo`, `sable_ref`, `crate_dir` вручную.
